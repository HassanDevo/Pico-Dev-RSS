# Copyright 2026 Google LLC. SPDX-License-Identifier: Apache-2.0
"""Version agreement, release identities, and archive checksum contracts."""

import hashlib
import json
from pathlib import Path
import runpy
import zipfile

import pytest

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def release(monkeypatch: pytest.MonkeyPatch) -> dict:
    monkeypatch.syspath_prepend(str(ROOT / "scripts"))
    return runpy.run_path(str(ROOT / "scripts/prepare_release.py"))


@pytest.mark.parametrize("tag", ["0.1.0", "v01.1.0", "v0.1.0-rc.1", "v0.1.0;echo bad"])
def test_reject_invalid_tag(release: dict, tag: str) -> None:
    with pytest.raises(ValueError, match="Tag must"):
        release["version_for_tag"](ROOT, tag)


def test_release_version_matches_source(release: dict) -> None:
    version = json.loads((ROOT / "plugin.json").read_text())["version"]
    assert release["version_for_tag"](ROOT, f"v{version}") == version


HOST_MANIFESTS = ("plugin.json", ".claude-plugin/plugin.json",
                  ".codex-plugin/plugin.json", ".cursor-plugin/plugin.json",
                  ".plugin/plugin.json")


@pytest.mark.parametrize("drifted", HOST_MANIFESTS)
def test_reject_host_version_drift(release: dict, tmp_path: Path, drifted: str) -> None:
    assert release["HOST_MANIFESTS"] == HOST_MANIFESTS
    for name in release["HOST_MANIFESTS"]:
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"version": "0.1.0"}))
    (tmp_path / drifted).write_text('{"version":"0.2.0"}')
    with pytest.raises(ValueError, match=f"^{drifted}: version must match"):
        release["version_for_tag"](tmp_path, "v0.1.0")


def test_prepare_exact_archives(release: dict, tmp_path: Path) -> None:
    version = json.loads((ROOT / "plugin.json").read_text())["version"]
    destination = tmp_path / "release"
    commit = "a" * 40
    release["prepare"](ROOT, f"v{version}", destination, commit)
    sums = (destination / "SHA256SUMS").read_text().splitlines()
    assert len(sums) == 2
    for line in sums:
        digest, name = line.split("  ")
        assert name in {f"egm-claude-{version}.zip", f"egm-openai-{version}.zip"}
        archive = destination / name
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == digest
        with zipfile.ZipFile(archive) as bundle:
            assert bundle.testzip() is None
            assert json.loads(bundle.read("plugin.json"))["version"] == version
    notes = (destination / "RELEASE_NOTES.md").read_text()
    assert f"Declared source: `{commit}`" in notes
    assert "Local source identity is caller-supplied and is not verified by this script." in notes
    assert "Publish only workflow-built candidates after exact-artifact checks." in notes
    with pytest.raises(FileExistsError):
        release["prepare"](ROOT, f"v{version}", destination, commit)


@pytest.mark.parametrize("commit", ["HEAD", "a" * 39, "a" * 41, "A" * 40,
                                   "g" * 40, "a" * 39 + "\n", "１" * 40])
def test_reject_invalid_commit_without_writing(
    release: dict, tmp_path: Path, commit: str,
) -> None:
    version = json.loads((ROOT / "plugin.json").read_text())["version"]
    destination = tmp_path / "release"
    with pytest.raises(ValueError, match="Git SHA"):
        release["prepare"](ROOT, f"v{version}", destination, commit)
    assert not destination.exists()


def test_prepare_cleans_partial_output_after_build_failure(
    release: dict, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    version = json.loads((ROOT / "plugin.json").read_text())["version"]
    destination = tmp_path / "release"
    prepare = release["prepare"]
    original_build = prepare.__globals__["build"]
    calls = 0

    def fail_second_build(*args, **kwargs):
        nonlocal calls
        calls += 1
        if calls == 2:
            raise RuntimeError("Simulated second-build failure")
        return original_build(*args, **kwargs)

    monkeypatch.setitem(prepare.__globals__, "build", fail_second_build)

    with pytest.raises(RuntimeError, match="Simulated second-build failure"):
        release["prepare"](ROOT, f"v{version}", destination, "a" * 40)

    assert not destination.exists()

    monkeypatch.setitem(prepare.__globals__, "build", original_build)
    release["prepare"](ROOT, f"v{version}", destination, "a" * 40)

    assert (destination / f"egm-claude-{version}.zip").is_file()
    assert (destination / f"egm-openai-{version}.zip").is_file()
    assert (destination / "SHA256SUMS").is_file()
