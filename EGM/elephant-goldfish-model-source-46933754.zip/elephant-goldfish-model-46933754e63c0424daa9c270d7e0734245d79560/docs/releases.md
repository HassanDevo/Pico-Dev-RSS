# Versioned releases

The canonical version is `plugin.json`'s `version`. Every host manifest that
declares an EGM version must match it, including experimental adapters such as
Cursor when present. Marketplace catalogs without a version field do not need
one. Version synchronization does not add a host to release support; other host
adapters still need explicit packaging and verification.

While EGM is pre-1.0, use patch bumps for compatible fixes and minor bumps for
features or incompatible workflow changes. Explain breaking changes in release
notes. Version 1.0 requires a stable contract for skill names, parameters, output
paths, and report formats. Do not change published artifacts under the same tag.

## Prepare a candidate

1. Update `plugin.json` and every host manifest (`.claude-plugin/plugin.json`,
   `.codex-plugin/plugin.json`, `.cursor-plugin/plugin.json`, and
   `.plugin/plugin.json`) to the same version in a reviewed PR.
   `scripts/prepare_release.py` rejects a tag when any of them differs.
2. Run `pytest tests/unit`. Include any migration notes in the PR.
3. A version change in `plugin.json` on `main` starts **Prepare draft release**.
   It tests and packages that commit before creating an annotated
   `vMAJOR.MINOR.PATCH` tag. An existing tag must point to the same commit.
4. To prepare a draft manually, create and push an annotated tag on a reviewed
   `main` commit, then dispatch **Prepare draft release** from `main` with that
   tag. Never move an existing release tag.
5. Review the draft's two runtime ZIPs, `SHA256SUMS`, the provenance bundle
   (`egm-vMAJOR.MINOR.PATCH.intoto.jsonl`), and source commit.
   Verify both ZIP attestations as described below. Replace
   placeholder notes with changes, compatibility/migration details, and exact
   artifact host-verification evidence. Unverified hosts remain unverified.
6. Publish the draft manually only after review. Directory publication is separate.

The workflow creates drafts and leaves publication to a maintainer. It does not
overwrite releases or run paid live tests. A duplicate release attempt fails
instead of replacing an existing release. Fix a failed build before creating a
new candidate version.
For local preparation, use a fresh output directory:

```sh
python scripts/prepare_release.py --tag v0.1.0 --commit "$(git rev-parse HEAD)" --output /tmp/egm-0.1.0-candidate
```

The local command checks manifest versions and builds artifacts. It does not
verify the caller-supplied source SHA, Git tag ancestry, or tests. Those checks
belong to the workflow. Publish only workflow-built candidates after
exact-artifact checks. Local builds remain diagnostic candidates.
Exact installed-bundle verification remains tracked in
[#60](https://github.com/google/elephant-goldfish-model/issues/60).

## Verify downloads

Download both ZIPs, `SHA256SUMS`, and the provenance bundle into one directory.
With GitHub CLI installed, run these commands from that directory:

```sh
sha256sum -c SHA256SUMS
for archive in egm-claude-*.zip egm-openai-*.zip; do
  gh attestation verify "$archive" --repo google/elephant-goldfish-model \
    --signer-workflow google/elephant-goldfish-model/.github/workflows/release.yml \
    --source-ref refs/heads/main || exit 1
done
```

The workflow signs both ZIP digests and stores provenance in GitHub before
creating a draft. The same attestation is attached to the release as
`egm-<tag>.intoto.jsonl`. It is not listed in `SHA256SUMS`. To verify a ZIP
against that downloaded bundle, pass it with `--bundle`:

```sh
gh attestation verify egm-claude-0.1.2.zip --repo google/elephant-goldfish-model \
  --bundle egm-v0.1.2.intoto.jsonl
```

Add the same `--signer-workflow` and `--source-ref` flags as above.

Signing failure blocks draft creation. Local preparation does not create
attestations. The build job uses `id-token: write` to request a signing
certificate and `attestations: write` to store the result. It cannot write releases.

The provenance identifies the workflow run from `main`. The tagged source checked
out during that run can be a different commit. Check the release notes for that
source SHA and inspect the workflow run before publication. Attestations do not
establish host support or prove that the code is safe.
